package com.mavenarchetype.microservice.response.pojos;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class MicroserviceGeneratorResponse {
	
	@JsonInclude(Include.NON_NULL)
	String errorMessage;
	
	@JsonInclude(Include.NON_NULL)
	String successMessage;

}

package com.mavenarchetype.microservice.request.pojos;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class Parameter {

	public String name;
	public String type;
}

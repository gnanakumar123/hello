package com.mavenarchetype.microservice.generator;

import java.util.ArrayList;
import java.util.Iterator;

import org.springframework.stereotype.Component;

import com.mavenarchetype.microservice.request.pojos.Command;
import com.mavenarchetype.microservice.request.pojos.MicroserviceGeneratorRequest;
import com.mavenarchetype.microservice.request.pojos.Parameter;
import com.mavenarchetype.microservice.request.pojos.Query;
import com.mavenarchetype.microservice.request.pojos.ReturnVal;
import com.mavenarchetype.microservice.utility.Utility;


@Component
public class RESTControllerGenerator {

	public void generateControllerForDomain(String outputDirectory, String domainName,
			MicroserviceGeneratorRequest microServiceJsonPojo) {

		StringBuffer strBuff = new StringBuffer();

		addImportAndClassDeclarationForController(domainName, strBuff);

		// getting command method info.
		// JSONArray commandArray = (JSONArray) jsonObject.get("commands");

		ArrayList<Command> commandArray = microServiceJsonPojo.getCommands();
		System.out.println("commandArray: " + commandArray);

		// getting queries method info.
		// JSONArray queriesArray = (JSONArray) jsonObject.get("queries");
		ArrayList<Query> queriesArray = microServiceJsonPojo.getQueries();
		System.out.println("queriesArray: " + queriesArray);

		// generate command methods
		generateMethodsForCommand(commandArray, strBuff, domainName);

		// generate quert methods
		generateMethodsForQuery(queriesArray, strBuff, domainName);

		strBuff.append("\n");
		strBuff.append("}");
		System.out.println(strBuff.toString());

		// String controllerFileName =
		// "C:\\Gnana\\kubernetes_learning\\maven_archetype\\dir_mvn_generation\\" +
		// domainName
		// + "Controller.java";

		String controllerFileLocation = outputDirectory + domainName + "\\" + "src\\main\\java\\com\\domain\\"
				+ domainName + "\\" + "controller\\" + domainName + "Controller.java";

		Utility.writeToJavaFile(strBuff, controllerFileLocation);

	}

	private void addImportAndClassDeclarationForController(String domainName, StringBuffer strBuff) {
		strBuff.append("package com.domain." + domainName + "." + "controller;");
		strBuff.append("\n\n");
		strBuff.append("import org.springframework.beans.factory.annotation.Autowired;");
		strBuff.append("\n");
		strBuff.append("import org.springframework.web.bind.annotation.DeleteMapping;");
		strBuff.append("\n");
		strBuff.append("import org.springframework.web.bind.annotation.GetMapping;");
		strBuff.append("\n");
		strBuff.append("import org.springframework.web.bind.annotation.PathVariable;");
		strBuff.append("\n");
		strBuff.append("import org.springframework.web.bind.annotation.PathVariable;");
		strBuff.append("\n");
		strBuff.append("import org.springframework.web.bind.annotation.PostMapping;");
		strBuff.append("\n");
		strBuff.append("import org.springframework.web.bind.annotation.PutMapping;");
		strBuff.append("\n");
		strBuff.append("import org.springframework.web.bind.annotation.RequestBody;");
		strBuff.append("\n");
		strBuff.append("import org.springframework.web.bind.annotation.RequestMapping;");
		strBuff.append("\n");
		strBuff.append("import org.springframework.web.bind.annotation.RestController;");
		strBuff.append("\n");
		strBuff.append("import com.domain." + domainName + ".model." + domainName + ";");
		strBuff.append("\n");
		strBuff.append("import com.domain." + domainName + ".service." + domainName + "Service;");
		strBuff.append("\n");

		strBuff.append("\n@RestController");
		strBuff.append("\n");
		strBuff.append("@RequestMapping(\"/api\")");
		strBuff.append("\n");
		strBuff.append("public class " + domainName + "Controller {");
		strBuff.append("\n\n");
		strBuff.append("@Autowired");
		strBuff.append("\n");
		strBuff.append("private " + domainName + "Service service;");
		strBuff.append("\n\n");
	}

	private void generateMethodsForCommand(ArrayList<Command> commandArray, StringBuffer strBuff, String domainName) {
		Iterator<Command> commandAndQueryIterator = commandArray.iterator();
		StringBuffer methodParamsStringBuffer = null;
		while (commandAndQueryIterator.hasNext()) {

			methodParamsStringBuffer = new StringBuffer();

			Command commandJsonObject = (Command) commandAndQueryIterator.next();
			System.out.println(commandJsonObject);

			String methodName = (String) commandJsonObject.getMethodName();
			System.out.println("methodName ::" + methodName);

			String methodAnnotation = generateAnnotations(methodName, domainName);

			ArrayList<Parameter> parametersArray =  commandJsonObject.getParameters();
			Iterator<Parameter> parametersIterator = parametersArray.iterator();

			while (parametersIterator.hasNext()) {

				Parameter parameterJsonObject = (Parameter) parametersIterator.next();
				String paramType = (String) parameterJsonObject.getType();
				String paramName = (String) parameterJsonObject.getName();

				System.out.println(paramType + " " + paramName);

				methodParamsStringBuffer.append("@PathVariable " + paramType + " " + paramName);
				if (parametersIterator.hasNext()) {
					methodParamsStringBuffer.append(",");
				}

			}

			String returnType = "";
			String returnName = "";

			if (commandJsonObject.getReturnVal() != null) {

				ReturnVal returnObject = (ReturnVal) commandJsonObject.getReturnVal();

				returnType = (String) returnObject.getType();
				returnName = (String) returnObject.getName();

			}

			System.out.println("returnType :: " + returnType + " " + returnName);

			// generate annotations
			strBuff.append(methodAnnotation);
			strBuff.append("\n");

			if (commandJsonObject.getReturnVal() == null) {

				strBuff.append("\tpublic " + "void" + " " + methodName + "(");
				strBuff.append(methodParamsStringBuffer.toString());

				strBuff.append("){");
				strBuff.append("\n\n");
			} else {

				strBuff.append("\tpublic " + returnType + " " + methodName + "(");
				strBuff.append(methodParamsStringBuffer.toString());

				strBuff.append("){");
				strBuff.append("\n\n");

				strBuff.append("\t" + returnType + " " + returnName + " = null;");

			}

			if (commandJsonObject.getReturnVal() != null) {

				strBuff.append("\n\treturn " + returnName + ";");
				strBuff.append("\n");
			}

			strBuff.append("\t}\n\n");

		}
	}

	private void generateMethodsForQuery(ArrayList<Query> queryArray, StringBuffer strBuff, String domainName) {

		Iterator<Query> queryIterator = queryArray.iterator();
		StringBuffer methodParamsStringBuffer = null;

		while (queryIterator.hasNext()) {

			methodParamsStringBuffer = new StringBuffer();

			Query queryJsonObject = (Query) queryIterator.next();
			System.out.println(queryJsonObject);

			String methodName = (String) queryJsonObject.getMethodName();
			System.out.println("methodName ::" + methodName);

			String methodAnnotation = generateAnnotations(methodName, domainName);

			ArrayList<Parameter> parametersArray = queryJsonObject.getParameters();
			Iterator<Parameter> parametersIterator = parametersArray.iterator();
			while (parametersIterator.hasNext()) {

				Parameter parameterJsonObject = (Parameter) parametersIterator.next();
				String paramType = (String) parameterJsonObject.getType();
				String paramName = (String) parameterJsonObject.getName();

				System.out.println(paramType + " " + paramName);

				methodParamsStringBuffer.append("@PathVariable " + paramType + " " + paramName);
				if (parametersIterator.hasNext()) {
					methodParamsStringBuffer.append(",");
				}

			}

			String returnType = "";
			String returnName = "";

			if (queryJsonObject.getReturnVal() != null) {

				ReturnVal returnObject = (ReturnVal) queryJsonObject.getReturnVal();

				returnType = (String) returnObject.getType();
				returnName = (String) returnObject.getName();

			}

			System.out.println("returnType :: " + returnType + " " + returnName);

			// generate annotations
			strBuff.append(methodAnnotation);
			strBuff.append("\n");

			if (queryJsonObject.getReturnVal() == null) {

				strBuff.append("\tpublic " + "void" + " " + methodName + "(");
				strBuff.append(methodParamsStringBuffer.toString());

				strBuff.append("){");
				strBuff.append("\n\n");
			} else {

				strBuff.append("\tpublic " + returnType + " " + methodName + "(");
				strBuff.append(methodParamsStringBuffer.toString());

				strBuff.append("){");
				strBuff.append("\n\n");

				strBuff.append("\t" + returnType + " " + returnName + " = null;");

			}

			if (queryJsonObject.getReturnVal() != null) {

				strBuff.append("\n\treturn " + returnName + ";");
				strBuff.append("\n");
			}

			strBuff.append("\t}\n\n");

		}
	}

	private String generateAnnotations(String methodName, String domainName) {

		String annotationString = "";

		if (methodName.startsWith("get") && methodName.endsWith("All")) {
			annotationString = "\t@GetMapping(\"/" + domainName + "\")";
		} else if (methodName.contains("get") || methodName.contains("retrieve") || methodName.contains("find")
				|| methodName.contains("search")) {
			annotationString = "\t@GetMapping(\"/" + domainName + "/{Id}\")";
		} else if (methodName.contains("add") || methodName.contains("save") || methodName.contains("post")) {
			annotationString = "\t@PostMapping(\"/" + domainName + "\")";
		} else if (methodName.contains("update")) {
			annotationString = "\t@PutMapping(\"/" + domainName + "\")";
		} else if (methodName.contains("delete")) {
			annotationString = "\t@DeleteMapping(\"/" + domainName + "/{Id}\")";
		}

		return annotationString;
	}

}
